﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanhiaAerea.Listas
{
    public class Voo
    {
        public int NumeroVoo { get; set; }
        public DateTime Horario { get; set; }
        public string Destino { get; set; }
    }
}
