﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CompanhiaAerea.Listas; //Acessa a pasta com as classes que possuem os objetos da listas.

namespace CompanhiaAerea
{
    class Program
    {
        static void CriaListaVoos()
        {
            VoosDisponiveis voos = new VoosDisponiveis(); // Instancia uma classe que possui um método que cria os vôos. 
            voos.VoosExistentes(); //Inicia o método que cria a lista de vôos.
        }

        static void PesquisaPassageiro(List<Passageiro> lista)
        {
            string cpf = string.Empty;

            Console.WriteLine("Qual lista de espera você");
            Console.WriteLine("NUMERO DO VOO: \n 1 - BH/Rio \n 2 - BH/SP \n 3 - BH/Recife");
            int voo = int.Parse(Console.ReadLine());            

            Console.WriteLine("PESQUISA DE PASSAGEIRO");
            Console.Write("INFORME O CPF: ");
            cpf = Console.ReadLine();

            var verfificaSeExistePassageiroComCpfInformado = lista.Count(x => x.NumeroVoo == voo && x.Cpf == cpf);   //Verifica se existe um passageiro com o cpf informado e do vôo informado.          

            if (verfificaSeExistePassageiroComCpfInformado != 0)
            {
                var dadosDoPassageiro = lista.Where(x => x.Cpf == cpf); // Obtém informações do passageiro.

                foreach (var item in dadosDoPassageiro)
                {
                    Console.WriteLine("DADOS DO PASSAGEIRO PESQUISADO:");

                    Console.WriteLine($"NOME: {item.Nome}");
                    Console.WriteLine($"SOBRENOME: {item.Sobrenome}");
                    Console.WriteLine($"CPF: {item.Cpf}");
                    Console.WriteLine($"TELEFONE: {item.Telefone}");
                    Console.WriteLine($"ENDEREÇO: {item.Endereco}");
                    Console.WriteLine($"NÚMERO DA PASSAGEM: {item.NumeroPassagem} ");
                    Console.WriteLine($"NÚMERO DO VÔO: {item.NumeroVoo}");
                    Console.WriteLine($"NÚMERO DA POLTRONA: {item.NumeroPoltrona}");
                    Console.WriteLine($"HORÁRIO: {item.Horario}");
                    Console.WriteLine("____________________________________________________________________");
                }
            }
            else Console.WriteLine("Passageiro não encontrado neste vôo.");
        }

        static List<Passageiro> CadastraPassageiro(List<Passageiro> lista)
        {
            string cpf, nome, sobrenome, endereco, telefone;
            int numeroPassagem, numeroVoo, numeroPoltrona;
            DateTime horario;

            Console.WriteLine("CADASTRO DE PASSAGEIRO: ");

            bool paradaLoop = true;
            do
            {
                Console.WriteLine("CPF: ");
                cpf = Console.ReadLine();

                ValidaInformacoes validacoes = new ValidaInformacoes();
                paradaLoop = validacoes.ValidaCPF(cpf); //Acessa o método que valida cpf e informa true ou false para o variável 'paradaLoop'

                if (paradaLoop == false)
                {
                    Console.WriteLine("CPF inválido, por favor insira um CPF válido para continuar o cadastro.");
                    paradaLoop = true;
                }
                else
                {
                    var cpfExistente = lista.Count(x => x.Cpf == cpf); //Verifica se o cpf digitado existe no sistema.

                    if (cpfExistente != 0)
                    {
                        Console.WriteLine("Cpf existente no sistema!");
                    }
                    else
                    {
                        paradaLoop = false;
                    }
                }

            } while (paradaLoop); //Caso o CPF seja inválido o sistema pede outro CPF. 

            Console.WriteLine("NOME:");
            nome = Console.ReadLine();

            Console.WriteLine("SOBRENOME:");
            sobrenome = Console.ReadLine();

            Console.WriteLine("ENDERECO:");
            endereco = Console.ReadLine();

            Console.WriteLine("TELEFONE:");
            telefone = Console.ReadLine();

            Console.WriteLine("NUMERO DO VOO: \n 1 - BH/Rio \n 2 - BH/SP \n 3 - BH/Recife");
            numeroVoo = int.Parse(Console.ReadLine());

            if (lista.Count(x => x.NumeroVoo == numeroVoo) != 0) //Caso o exista algum registro o sistema executa o código  abaixo.
            {
                int numeroUltimaPaumerssagemVendida = lista.Max(x => x.NumeroPassagem);
                numeroPassagem = numeroUltimaPaumerssagemVendida + 1;

                int numeroUltimaPoltronaVendida = lista.Max(x => x.NumeroPoltrona);
                numeroPoltrona = numeroUltimaPoltronaVendida + 1;
            }
            else //Caso não exista registro o sistema inicia o número da passagem e o número da poltrona com 1. 
            {
                numeroPassagem = 1;
                numeroPoltrona = 1;
            }

            //De acordo com os cóigos dos vôos informados as datas serão inseridas automaticamente. 
            if (numeroVoo == 1)
                horario = new DateTime(2019, 1, 1, 13, 00, 00);
            else if (numeroVoo == 2)
                horario = new DateTime(2019, 1, 1, 13, 30, 00);
            else if (numeroVoo == 3)
                horario = new DateTime(2019, 1, 1, 14, 00, 00);
            else
                horario = new DateTime();

            /* Caso o número de passagens que foram vendidas seja maior que 0 e menor ou igual a 15 é inserido um novo 
               cliente, senão ele é cadastrado na lista de espera. */
            if (lista.Count(x => x.NumeroVoo == numeroVoo) >= 0 &&
                lista.Count(x => x.NumeroVoo == numeroVoo) <= 5) // Mudar para 5
            {
                lista.Add(new Passageiro
                {
                    Nome = nome,
                    Sobrenome = sobrenome,
                    Cpf = cpf,
                    Telefone = telefone,
                    Endereco = endereco,
                    NumeroPassagem = numeroPassagem,
                    NumeroVoo = numeroVoo,
                    NumeroPoltrona = numeroPoltrona,
                    Horario = horario,
                    VendaBloqueada = false
                });
            }
            else
            {
                lista.Add(new Passageiro
                {
                    Nome = nome,
                    Sobrenome = sobrenome,
                    Cpf = cpf,
                    Telefone = telefone,
                    Endereco = endereco,
                    NumeroPassagem = numeroPassagem,
                    NumeroVoo = numeroVoo,
                    NumeroPoltrona = numeroPoltrona,
                    Horario = horario,
                    VendaBloqueada = true
                });
            }

            return lista;
        }
        static List<Passageiro> ExcluirPassageiro(List<Passageiro> lista)
        {
            string cpf;
            Console.WriteLine("CPF: ");
            cpf = Console.ReadLine();

            var verificaCpfExistente = lista.Count(x => x.Cpf == cpf);
            if (verificaCpfExistente != 0)
            {
                Console.WriteLine("Tem certeza que deseja exluir este passageiro da lista?");
                Console.WriteLine("1 - Sim/n 2 - Não");
                string resposta = Console.ReadLine();
                if (resposta == "1")
                {
                    lista.RemoveAll(x => x.Cpf == cpf);
                    Console.WriteLine("Cadastro excluído!");
                }
                else
                {
                    Console.WriteLine("Operação de exlusão cancelada!");
                    Console.WriteLine("Não foi possível excluir nenhuma informação..");
                }
            }
            else
            {
                Console.WriteLine("Cadastro não existente.");
            }

            return lista;
        }

        static List<Espera> CadastraPassageiroListaDeEspera(List<Espera> listaEspera, List<Passageiro> listaPassageiro)
        {

            var informacoes = from x in listaPassageiro where x.VendaBloqueada == true select x; // Pega as informações que tiveram a venda bloqueada.  

            foreach (var item in informacoes)
            {
                int listaDeEsperaPorVoo = listaEspera.Count(x => x.NumeroVoo == item.NumeroVoo);

                if (listaDeEsperaPorVoo <= 5) // Caso a lista de espera por vôo contenha menos de 5 pessoas é inclúido uma pessoa a lista.
                {
                    var cadastroPresenteNaEspera = from x in listaEspera where x.Cpf == item.Cpf select x; //Verifica se o cadastro já está presente na lista de espera.
                    if (cadastroPresenteNaEspera != null)
                    {
                        listaEspera.Add(new Espera
                        {
                            Nome = item.Nome,
                            Sobrenome = item.Sobrenome,
                            Cpf = item.Cpf,
                            Endereco = item.Endereco,
                            Telefone = item.Telefone,
                            NumeroVoo = item.NumeroVoo
                        });
                    }
                    else Console.WriteLine("Cliente já presente na lista de espera.");
                }
                else Console.WriteLine("A lista de espera para este vôo já está cheia. Aguarde uma nova lista a ser aberta.");
            }

            return listaEspera;
        }

        static void ExibeListaPassageiro(List<Passageiro> listaPassageiro)
        {
            foreach (var item in listaPassageiro)
            {
                Console.WriteLine($"NOME: {item.Nome}");
                Console.WriteLine($"SOBRENOME: {item.Sobrenome}");
                Console.WriteLine($"CPF: {item.Cpf}");
                Console.WriteLine($"TELEFONE: {item.Telefone}");
                Console.WriteLine($"ENDEREÇO: {item.Endereco}");
                Console.WriteLine($"NÚMERO DA PASSAGEM: {item.NumeroPassagem} ");
                Console.WriteLine($"NÚMERO DO VÔO: {item.NumeroVoo}");
                Console.WriteLine($"NÚMERO DA POLTRONA: {item.NumeroPoltrona}");
                Console.WriteLine($"HORÁRIO: {item.Horario}");
                Console.WriteLine("____________________________________________________________________");
            }
        }

        static void ExibeListaDeEspera(List<Espera> listaEspera)
        {
            Console.WriteLine("Qual lista de espera você");
            Console.WriteLine("NUMERO DO VOO: \n 1 - BH/Rio \n 2 - BH/SP \n 3 - BH/Recife");
            int valor = int.Parse(Console.ReadLine());

            var query = listaEspera.Where(x => x.NumeroVoo == valor); //Busca passageiro por vôo.

            foreach (var item in query)
            {
                Console.WriteLine($"NOME: {item.Nome}");
                Console.WriteLine($"SOBRENOME: {item.Sobrenome}");
                Console.WriteLine($"CPF: {item.Cpf}");
                Console.WriteLine($"TELEFONE: {item.Telefone}");
                Console.WriteLine($"ENDEREÇO: {item.Endereco}");
                Console.WriteLine($"NÚMERO DA PASSAGEM: {item.NumeroPassagem} ");
                Console.WriteLine($"NÚMERO DO VÔO: {item.NumeroVoo}");
                Console.WriteLine($"NÚMERO DA POLTRONA: {item.NumeroPoltrona}");
                Console.WriteLine($"HORÁRIO: {item.Horario}");
                Console.WriteLine("____________________________________________________________________");
            }
        }
                     
        static void Main(string[] args)
        {
            List<Passageiro> listaPassageiro = new List<Passageiro>();
            List<Espera> listaDeEspera = new List<Espera>();
            CriaListaVoos();


            bool paradaBool = true;
            do
            {
                Console.Clear();
                Console.WriteLine("MENU");
                Console.WriteLine("F1 - Lista de Passageiros");
                Console.WriteLine("F2 - Pesquisar Passageiro");
                Console.WriteLine("F3 - Cadastrar Passageiro");
                Console.WriteLine("F4 - Exluir Passageiro");
                Console.WriteLine("F5 - Exibir Lista de Espera");
                Console.WriteLine("ES - Sair do Sistema");

                ConsoleKeyInfo tecla;
                Console.WriteLine("Tecla");
                tecla = Console.ReadKey();
                switch (tecla.Key)
                {
                    case ConsoleKey.F1:
                        Console.Clear();
                        Console.WriteLine("F1");
                        ExibeListaPassageiro(listaPassageiro);
                        Console.WriteLine("Pessione alguma tecla para continuar..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case ConsoleKey.F2:
                        Console.Clear();
                        Console.WriteLine("F2");
                        PesquisaPassageiro(listaPassageiro);
                        Console.WriteLine("Pessione alguma tecla para continuar..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case ConsoleKey.F3:
                        Console.Clear();
                        Console.WriteLine("F3");
                        listaPassageiro = CadastraPassageiro(listaPassageiro);
                        listaDeEspera = CadastraPassageiroListaDeEspera(listaDeEspera, listaPassageiro); // Adiciona passageiro com venda bloqueada a lista de espera.
                        listaPassageiro.RemoveAll(x => x.VendaBloqueada == true); // Exlui passageiro que teve venda bloqueada.
                        Console.WriteLine("Pessione alguma tecla para continuar..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case ConsoleKey.F4:
                        Console.Clear();
                        Console.WriteLine("F4");
                        listaPassageiro = ExcluirPassageiro(listaPassageiro); //Exlui passageiro da Lista de passageiro.
                        Console.WriteLine("Pessione alguma tecla para continuar..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case ConsoleKey.F5:
                        Console.Clear();
                        Console.WriteLine("F5");
                        ExibeListaDeEspera(listaDeEspera);
                        Console.WriteLine("Pessione alguma tecla para continuar..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    case ConsoleKey.Escape:
                        Console.Clear();
                        Console.WriteLine("ESC");
                        paradaBool = false;
                        Console.WriteLine("Aplicaçao encerrada.");
                        Console.WriteLine("Pessione alguma tecla para continuar..");
                        Console.ReadKey();
                        Console.Clear();
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Opção inexistente.");
                        Console.Clear();
                        break;
                }
            }
            while (paradaBool);
        }
    }
}
